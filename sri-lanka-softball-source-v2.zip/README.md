# Sri Lanka Softball Starter

Phone-friendly static HTML prototype.

## Publish with GitHub Pages
1. Create a public repository named `sri-lanka-softball`.
2. Upload `index.html` and commit the files.
3. Open Settings → Pages.
4. Choose Deploy from a branch, branch `main`, folder `/(root)`, then Save.
5. Wait for GitHub Pages to show the site URL.

## Limitations
This starter stores data in the current browser only. It does not synchronize scores to another device or OBS PC. Add a shared backend such as Supabase before using for multi-device live scoring or official tournaments.
