# Sri Lanka Softball — mobile starter

This is a no-build static HTML starter. Open `index.html` in a browser or publish it with GitHub Pages.

## Phone-only publish
1. Sign in at github.com.
2. Create a new **Public** repository named `sri-lanka-softball`.
3. Choose **Add file → Upload files**.
4. Upload `index.html` from this folder, then **Commit changes**.
5. Open **Settings → Pages**.
6. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, and Save.
7. Wait for the published URL shown on the Pages settings page.

## Important
This starter stores records in localStorage on the same browser. It does not synchronize data between your phone and another device/OBS computer. It is a starting prototype, not a complete production scoring engine. A shared backend such as Supabase and further validation are needed for reliable multi-device live scoring, full rules, photo uploads, authentication, and official use.
